﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospi_hospital_only
{
    public partial class Reception_First : Form
    {
        public Reception_First()
        {
            InitializeComponent();
        }

        private void Receipt_First_Load(object sender, EventArgs e)
        {
             // 폼 로드시 수신자명 포커스
            this.ActiveControl = textBox1;

            //  접수 시간
            textBox5.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
        }
    }
}
