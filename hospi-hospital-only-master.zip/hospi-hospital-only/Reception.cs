﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospi_hospital_only
{
    public partial class Reception : Form
    {
        public Reception()
        {
            InitializeComponent();
        }

        // 진료정보의 접수일, 접수시간 초기화 & 현재 체크박스 체크
        public void TimeNow()
        {
            dateTimePicker1.Text = DateTime.Now.ToString("yyyy-MM-dd");
            comboBox2.Text = DateTime.Now.ToString("HH");
            comboBox3.Text = DateTime.Now.ToString("mm");
            checkBox2.Checked = true;
        }

        // 접수 현황 버튼 ▶◀ 삭제
        public void ButtonClearL()
        {
            button2.Text = "접수환자";
            button5.Text = "진료보류";
        }

        // 수납 현황 버튼 ▶◀ 삭제
        public void ButtonClearR()
        {
            button8.Text = "수납대기";
            button13.Text = "수납완료";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        // 새로고침 버튼 이미지
        private void label2_MouseEnter(object sender, EventArgs e)
        {
            label2.ImageIndex = 1;
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.ImageIndex = 0;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.ImageIndex = 0;
        }

        private void Receipt_Load(object sender, EventArgs e)
        {
            // 폼 로드시 버튼 클릭
            button2_Click(sender, e);
            button8_Click(sender, e);

            // 폼 로드시 수신자명 포커스
            this.ActiveControl = textBox23;

            // 리스트뷰 속성
            listView1.GridLines = true;
            listView2.GridLines = true;
            listView3.GridLines = true;
            listView1.FullRowSelect = true;
            listView2.FullRowSelect = true;
            listView3.FullRowSelect = true;

            // 접수시간 (현재)
            TimeNow();
        }

        // 초진등록
        private void button7_Click(object sender, EventArgs e)
        {
            Reception_First receipt_First = new Reception_First();
            receipt_First.Show();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            // (현재) 접수 체크변경
            if (checkBox2.Checked == true)
            {
                dateTimePicker1.Enabled = false;
                comboBox2.Enabled = false;
                comboBox3.Enabled = false;
                TimeNow();
            }
           else if (checkBox2.Checked == false)
            {
                dateTimePicker1.Enabled = true;
                comboBox2.Enabled = true;
                comboBox3.Enabled = true;
            }
        }

        // 접수환자 버튼
        private void button2_Click(object sender, EventArgs e)
        {
            ButtonClearL();
            button2.Text = "▶ " + button2.Text + " ◀";
        }

        // 진료보류 버튼
        private void button5_Click(object sender, EventArgs e)
        {
            ButtonClearL();
            button5.Text = "▶ " + button5.Text + " ◀";
        }

        // 수납대기 버튼
        private void button8_Click(object sender, EventArgs e)
        {
            ButtonClearR();
            button8.Text = "▶ " + button8.Text + " ◀";
        }

        // 수납완료 버튼
        private void button13_Click(object sender, EventArgs e)
        {
            ButtonClearR();
            button13.Text = "▶ " + button13.Text + " ◀";
        }
    }
}
